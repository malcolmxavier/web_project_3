Project name: Malcolm X's 2nd Yandex Project v1.0

This is a sample project to demonstrate grasp of HTML and CSS skills.

This project employs HTML, CSS, and Nested BEM structure.

Improvements to code, to increase efficiency and adherence to specifications provided by Yandex, will be made as necessary.

https://malcolmxavier.github.io/web_project_3/